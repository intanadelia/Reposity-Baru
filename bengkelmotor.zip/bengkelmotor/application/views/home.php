<div class="alert alert-success">
  <strong>Selamat Datang</a>
   </strong> 
</div>

<!--<div class="alert alert-info">
  </div>-->

